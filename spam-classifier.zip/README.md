# 📧 Spam Email Detection using Scikit-learn

This project builds a predictive model to classify SMS messages as spam or not using a Naive Bayes classifier.

## 📁 Dataset

Use the [SMS Spam Collection dataset](https://www.kaggle.com/datasets/uciml/sms-spam-collection-dataset).

Place the downloaded `spam.csv` in the same directory as the script.

## 🚀 How to Run

```bash
pip install -r requirements.txt
python spam_classifier.py
```

## 🧠 Model

- Model: Multinomial Naive Bayes
- Text vectorization: CountVectorizer
- Accuracy and classification report printed in terminal

