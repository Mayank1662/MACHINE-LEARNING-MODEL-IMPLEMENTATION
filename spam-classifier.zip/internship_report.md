# Internship Project Report

## Title
Spam Email Detection using Machine Learning

## Objective
Build a predictive model to detect spam messages using text classification techniques.

## Tools & Technologies
- Python 3
- scikit-learn
- pandas

## Dataset
SMS Spam Collection Dataset (from Kaggle)

## Methodology
1. Preprocessed SMS text and converted labels (ham = 0, spam = 1)
2. Vectorized text data using CountVectorizer
3. Trained Naive Bayes model
4. Evaluated model using accuracy and classification report

## Results
- Accuracy: ~98%
- The model successfully distinguishes between spam and non-spam messages.

## Conclusion
Built a working spam detection ML pipeline using scikit-learn and basic text processing.

## Submitted By
Max (Internship Candidate)
